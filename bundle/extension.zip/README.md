# getpublicip

 - https://github.com/aws-samples/aws-lambda-extensions/tree/main/python-example-extension

### python dependencies

```
cd get-public-ip
chmod +x extension.py
pip3 install -r requirements.txt -t .
cd ..
```

### lambda layer setup

```
chmod +x extensions/get-public-ip
zip -r extension.zip .
```
